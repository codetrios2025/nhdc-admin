import { Routes, Route, Navigate } from "react-router-dom";

import Login from "../features/auth/pages/Login";

import Dashboard from "../pages/dashboard";

import DashboardLayout from "../layouts/DashboardLayout";

import ProtectedRoute from "./ProtectedRoute";

import DoctorList from "../features/doctors/pages/DoctorList";

import DoctorCreate from "../features/doctors/pages/DoctorCreate";

import EditDoctor from "../features/doctors/pages/EditDoctor";

import DoctorView from "../features/doctors/pages/DoctorView";

import VideoList from "../features/videos/pages/VideoList";
import VideoCreate from "../features/videos/pages/VideoCreate";
import EditVideo from "../features/videos/pages/EditVideo";
import ViewVideo from "../features/videos/pages/ViewVideo";

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/login" />} />

      <Route path="/login" element={<Login />} />

      <Route
        element={
          <ProtectedRoute>
            <DashboardLayout />
          </ProtectedRoute>
        }
      >
        <Route path="/dashboard" element={<Dashboard />} />

        <Route path="/doctors" element={<DoctorList />} />

        <Route path="/doctors/create" element={<DoctorCreate />} />

        <Route path="/doctors/:id/edit" element={<EditDoctor />} />

        <Route path="/doctors/:id" element={<DoctorView />} />

        <Route path="/videos" element={<VideoList />} />

        <Route path="/videos/create" element={<VideoCreate />} />

        <Route path="/videos/:id/edit" element={<EditVideo />} />

        <Route path="/videos/:id" element={<ViewVideo />} />
      </Route>
    </Routes>
  );
};

export default AppRoutes;
